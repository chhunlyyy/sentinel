# Sentinel shared repo

This private repository holds what the team shares across Sentinel runs. It is cloned to `.sentinel/shared/` in each workspace by `sentinel sync pull`.

| Path | What it holds |
|---|---|
| `invariants.md` | project rules every increment must satisfy |
| `guidelines/` | extra instructions appended to stage prompts (referenced from `sentinel.config.yaml`) |
| `specs/` | one spec per increment, plus `index.md` and `index.json` |
| `regression/` | the accumulated regression suite, one file per increment |

Keep this repository private. Never commit real names, government or national ids, emails, tokens or passwords; `sentinel scrub --check` blocks a push when it recognizes them.
